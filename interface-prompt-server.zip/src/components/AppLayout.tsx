import React from 'react';
import OllamaInterface from './OllamaInterface';

const AppLayout: React.FC = () => {
  return <OllamaInterface />;
};

export default AppLayout;
